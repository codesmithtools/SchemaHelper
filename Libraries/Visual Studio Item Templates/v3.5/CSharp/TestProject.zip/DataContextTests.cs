﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using $entityNamespace$;

namespace $rootnamespace$
{
    /// <summary>
    /// Summary description for DataContextTests
    /// </summary>
    [TestClass]
    public class DataContextTests
    {
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext { get; set; }


        [TestMethod]
        public void CreateContext()
        {
            var db = new $datacontext$();
            Assert.IsNotNull(db);
        }
    }
}
