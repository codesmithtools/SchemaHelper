﻿
Class Site
    Inherits MasterPage

    
    
End Class
